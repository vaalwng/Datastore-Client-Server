package utd.persistentDataStore.datastoreServer.commands;

import java.io.IOException;
import java.util.List;

import utd.persistentDataStore.utils.FileUtil;
import utd.persistentDataStore.utils.ServerException;
import utd.persistentDataStore.utils.StreamUtil;

public class ServerCommandDirectory extends ServerCommand {

	public void run() throws IOException, ServerException 
	{
		List<String> files = FileUtil.directory();		
		int n = files.size();
		sendOK();
		StreamUtil.writeLine(n + "\n", outputStream);
		for(int i = 0; i < n; i++)
		{
			StreamUtil.writeLine(files.get(i), outputStream);
		}
	}	
	
}