package utd.persistentDataStore.datastoreServer.commands;

import java.io.IOException;

import utd.persistentDataStore.utils.FileUtil;
import utd.persistentDataStore.utils.StreamUtil;
import utd.persistentDataStore.utils.ServerException;

public class ServerCommandDelete extends ServerCommand {
	
	public void run() throws IOException, ServerException
	{
		String n = StreamUtil.readLine(inputStream);
		if(n == null || n.equals(""))
		{
			sendError("ERROR: DeleteCommand readLine - string not recognized: " + n);
		}
		
		if(FileUtil.deleteData(n))
		{
			sendOK();
		}
		else
		{
			throw new ServerException("ERROR: failed to delete.");
		}
	}
	
}
