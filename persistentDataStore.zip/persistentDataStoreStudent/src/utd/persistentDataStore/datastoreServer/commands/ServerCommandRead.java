package utd.persistentDataStore.datastoreServer.commands;

import java.io.IOException;

import utd.persistentDataStore.utils.FileUtil;
import utd.persistentDataStore.utils.ServerException;
import utd.persistentDataStore.utils.StreamUtil;

public class ServerCommandRead extends ServerCommand {

	public void run() throws IOException, ServerException
	{
		String n = StreamUtil.readLine(inputStream);
		if(n == null || n.equals(""))
		{
			sendError("ERROR: ReadCommand readLine - string not recognized: " + n);
		}
		
		byte[] data = FileUtil.readData(n);	
		sendOK();
		StreamUtil.writeLine("" + data.length, outputStream);
		StreamUtil.writeData(data, outputStream);
	}
	
}
