package utd.persistentDataStore.datastoreServer.commands;

import java.io.IOException;

import utd.persistentDataStore.utils.FileUtil;
import utd.persistentDataStore.utils.ServerException;
import utd.persistentDataStore.utils.StreamUtil;

public class ServerCommandWrite extends ServerCommand {

	public void run() throws IOException, ServerException
	{
		String n = StreamUtil.readLine(inputStream);
		if(n == null || n.equals(""))
		{
			sendError("ERROR: WriteCommand readLine - string not recognized: " + n);
		}
		
		int s = Integer.parseInt(StreamUtil.readLine(inputStream));
		byte[] data = StreamUtil.readData(s, inputStream);
		FileUtil.writeData(n, data);
		sendOK();
	}
	
}
