package utd.persistentDataStore.datastoreClient;

import utd.persistentDataStore.utils.StreamUtil;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import java.util.ArrayList;
import java.util.List;

public class DatastoreClientImpl implements DatastoreClient
{
	private InetAddress address;
	private int port;
	private InputStream inputStream;
	private OutputStream outputStream;

	public DatastoreClientImpl(InetAddress address, int port)
	{
		this.address = address;
		this.port = port;
	}

	private void establishSocket() throws IOException {		
		System.out.println("Establishing Socket Connection...");
		
		SocketAddress sAddr = new InetSocketAddress(address, port);		
		Socket socket = new Socket(address, port);
		try 
		{			
			socket.connect(sAddr); 		
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		}		
		inputStream = socket.getInputStream();
		outputStream = socket.getOutputStream();		
	}
	
	/* (non-Javadoc)
	 * @see utd.persistentDataStore.datastoreClient.DatastoreClient#write(java.lang.String, byte[])
	 */	
	@Override
    public void write(String name, byte data[]) throws ClientException
	{
		try 
		{	
			
			establishSocket();
			
			// Writing 
			StreamUtil.writeLine("write", outputStream);
			StreamUtil.writeLine(name, outputStream);
			StreamUtil.writeLine("" + data.length, outputStream);
			StreamUtil.writeData(data, outputStream);
						
			// Reading 
			String response = StreamUtil.readLine(inputStream);
			System.out.println("Response: " + response);			
			if (!response.equalsIgnoreCase("OK")) {
				throw new ClientException("ERROR: write() failure.");
			}			
		} 
		catch (IOException e) 
		{
			throw new ClientException(e.getMessage());
		} 
	}

	/* (non-Javadoc)
	 * @see utd.persistentDataStore.datastoreClient.DatastoreClient#read(java.lang.String)
	 */
	@Override
    public byte[] read(String name) throws ClientException
	{
		byte[] data;
		try 
		{	
			establishSocket();
			
			// Writing
			StreamUtil.writeLine("read", outputStream);
			StreamUtil.writeLine(name, outputStream);
			
			// Reading
			String response = StreamUtil.readLine(inputStream);
			System.out.println("Response: " + response);			
			if (response.equalsIgnoreCase("OK")) {
				int s = Integer.parseInt(StreamUtil.readLine(inputStream));
				data = StreamUtil.readData(s, inputStream);

			} else {
				throw new ClientException("ERROR: read() failure.");
			}
		} 
		catch (IOException e) 
		{
			throw new ClientException(e.getMessage());
		}
		return data;
	}

	/* (non-Javadoc)
	 * @see utd.persistentDataStore.datastoreClient.DatastoreClient#delete(java.lang.String)
	 */
	@Override
    public void delete(String name) throws ClientException
	{
		try 
		{
			establishSocket();
			
			// Writing
			StreamUtil.writeLine("delete", outputStream);
			StreamUtil.writeLine(name, outputStream);
			
			// Reading
			String response = StreamUtil.readLine(inputStream);
			System.out.println("Response: " + response);
			if (!response.equalsIgnoreCase("ok")) {
				throw new ClientException("ERROR: delete() failure.");
			}
		} 
		catch (IOException e) 
		{
			throw new ClientException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see utd.persistentDataStore.datastoreClient.DatastoreClient#directory()
	 */
	@Override
    public List<String> directory() throws ClientException
	{	
		List<String> files = new ArrayList<String>();
		try 
		{
			establishSocket();
			
			// Writing
			StreamUtil.writeLine("directory", outputStream);
			
			// Reading
			String response = StreamUtil.readLine(inputStream);
			if (response.equalsIgnoreCase("OK")) {
				int n = Integer.parseInt(StreamUtil.readLine(inputStream));
				for (int i = 0; i < n; i++) {
					String file = StreamUtil.readLine(inputStream);
					files.add(file);
				}
			} else {
				throw new ClientException("Failed reading");
			}
		} 
		catch (IOException e) 
		{
			throw new ClientException(e.getMessage());
		}
		return files;
	}
}